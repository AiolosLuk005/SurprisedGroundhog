LAN 安全版说明：运行 app_lan.py 即可，仅提供 AI 接口，扫描在本机完成。
