# -*- coding: utf-8 -*-
"""
Surprised Groundhog - LAN/Full 合并入口
- "/"        : LAN 安全版（本地浏览器扫描，不暴露服务器文件系统）
- "/full/*"  : 完整版（导出CSV/导入MySQL/移动/重命名/删除/关键词等）仅允许本机访问
- 兜底修复  : 旧前端把接口打到根路径时(如 /scan)，自动 307 到 /full/*
"""
from flask import Flask, render_template, request, abort, redirect, jsonify, send_from_directory
from api.ai import bp as ai_bp         # AI 关键词接口（不接收路径/内容）
from api.routes import bp as full_bp   # 完整版蓝图
from core.config import PORT
import os

ROOT_API_PATHS = {
    "/scan", "/page",
    "/export", "/import",
    "/move", "/rename", "/trash",
    "/kw", "/preview",
}

def create_app():
    app = Flask(__name__, template_folder="templates", static_folder="static")
    # 开启模板自动重载 + 禁用静态缓存（开发期用）
    app.config['TEMPLATES_AUTO_RELOAD'] = True
    app.jinja_env.auto_reload = True
    app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

    # 首页：LAN 安全版
    @app.get("/")
    def landing():
        return render_template("index_lan.html")

    # 新增：直接渲染你放在 templates/ 里的 full.html
    @app.get("/full/ui")
    def full_ui():
        return render_template("full.html")

    # AI 蓝图
    app.register_blueprint(ai_bp)

    # 完整版蓝图挂到 /full
    app.register_blueprint(full_bp, url_prefix="/full")

    # 仅允许本机访问 /full/*
    @app.before_request
    def _only_local_for_full():
        p = (request.path or "/")
        if p.startswith("/full"):
            ra = (request.remote_addr or "")
            if ra not in ("127.0.0.1", "::1"):
                abort(403)
        return None

    # 兜底：旧前端误打根路径时 307 重写到 /full/*
    @app.before_request
    def _rewrite_legacy_root_paths():
        p = (request.path or "/")
        if p.startswith("/full") or p.startswith("/static") or p.startswith("/api/ai"):
            return None
        if p == "/ls":
            return None  # /ls 保留在根路径
        if p in ROOT_API_PATHS:
            target = "/full" + request.path
            if request.query_string:
                target += "?" + request.query_string.decode("utf-8", errors="ignore")
            return redirect(target, code=307)
        return None

    # 目录浏览接口（供前端选择目录用）
    @app.get("/ls")
    def ls_root():
        def list_windows_drives():
            subs = []
            for code in range(ord('C'), ord('Z') + 1):
                root = f"{chr(code)}:/"
                if os.path.exists(root):
                    subs.append(root)
            return subs

        def list_posix_root():
            try:
                with os.scandir("/") as it:
                    return [os.path.join("/", e.name) for e in it if e.is_dir()]
            except Exception:
                return []

        dir_arg = request.args.get("dir")
        if not dir_arg:
            if os.name == "nt":
                return jsonify({"ok": True, "dir": "", "subs": list_windows_drives()})
            else:
                return jsonify({"ok": True, "dir": "", "subs": list_posix_root()})

        base = (dir_arg or "").replace("\\", "/")
        subs = []
        try:
            if os.path.exists(base):
                with os.scandir(base) as it:
                    for e in it:
                        if e.is_dir():
                            subs.append(os.path.join(base, e.name))
            subs.sort(key=lambda s: s.lower())
        except Exception:
            subs = []
        return jsonify({"ok": True, "dir": base, "subs": subs})

    # 补 favicon，去掉 404 噪音（把 static/favicon.ico 放上更好）
    @app.route('/favicon.ico')
    def favicon():
        try:
            return send_from_directory(app.static_folder, 'favicon.ico')
        except Exception:
            # 返回一个极简空图标，避免 404
            from flask import Response
            ico_bytes = bytes.fromhex(
                "00000100010010100000010020006804000016000000280000001000000020000000010020000000000000040000"
                "130B0000130B00000000000000000000"
            )
            return Response(ico_bytes, mimetype='image/x-icon')
        
    # 全局禁止缓存（强制浏览器每次都拉新）
    @app.after_request
    def add_no_cache_headers(resp):
        resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, max-age=0'
        resp.headers['Pragma'] = 'no-cache'
        resp.headers['Expires'] = '0'
        return resp

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(host="0.0.0.0", port=PORT, debug=False)
