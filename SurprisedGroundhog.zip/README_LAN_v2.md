LAN 安全版 v2：
- “选择目录”优先使用 File System Access API（HTTPS/localhost 可用），不会出现“上传 X 个文件”的提示。
- 如果不满足安全上下文，自动回退到 `<input webkitdirectory>`，并在页面给出说明：那只是授权提示，页面不会上传。
- “类型”多选框与“类别”联动：选择类别后，仅显示该类别的后缀；默认显示全部后缀。多选框更高更宽便于选择。
使用：解压到项目根目录并运行 `python app_lan.py`。
