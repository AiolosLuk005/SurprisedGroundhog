# Surprised Groundhog (Refactored)
- `app.py` 仅负责创建 Flask 实例并注册蓝图。
- 业务/工具函数被移动到 `core/`。
- 所有 Web 路由集中在 `api/routes.py`，并保持与旧版接口 **兼容**（/scan、/export_csv、/import_mysql、/ls、/keywords、/apply_ops、/file、/thumb）。
- 前端文件保留在 `static/`，模板在 `templates/`。

## 运行
```bash
pip install -r requirements.txt
python app.py
```

## 结构
```
core/
  config.py, models.py, state.py
  utils/iterfiles.py
  extractors.py, ollama.py, mysql_log.py
api/
  routes.py
templates/index.html
static/{app.js, style.css, Logo.png}
config.toml, state.json, requirements.txt
```
