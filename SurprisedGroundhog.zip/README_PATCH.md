# Surprised Groundhog — Plugins & Config Scaffold (Patch 2025-08-17)
This patch adds a lightweight plugin system and a dedicated `config/` directory.

## What’s included
- `core/plugin_base.py`: plugin interface + registry
- `core/plugin_loader.py`: discovery under `plugins/`
- `plugins/`:
  - `archive_keywords.py` — zip/rar/7z filename keyword extractor
  - `pdf_basic.py` — basic PDF text extractor (PyPDF2)
  - `text_basic.py` — text-like files (txt/md/rtf/json/yaml)
- `config/plugins.toml` — toggle and order plugins
- `core/extractors_patch.py` — plugin-aware wrapper around your existing `core/extractors.py`

## How to integrate
1. **Copy files** from this patch into your project at the same paths.
2. In `api/routes.py`, replace imports:
   ```python
   # from core.extractors import extract_text_for_keywords
   from core.extractors_patch import extract_text_for_keywords
   ```
3. Keep your original `core/extractors.py` as fallback for types without plugins.
4. Drop future recognizers into `plugins/` and export them via `register(...)`.

> No breaking changes to your current endpoints — you simply gain plugin override capability.
